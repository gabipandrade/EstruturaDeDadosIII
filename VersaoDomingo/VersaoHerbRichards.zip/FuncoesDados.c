#include "FuncoesCabecalho.h"
#include "cabeca.h"
#include "AberturaArquivo.h"
#include "FuncoesDados.h"
#include "Funcionalidades.h"
#include "Funcoesfornecidas.h"

RegistroDeDados *CriaStructRegDados(){
    RegistroDeDados *RegDados;
    RegDados=(RegistroDeDados*)malloc(sizeof(RegistroDeDados));
    if(RegDados==NULL){
        return NULL;
    }
    strcpy(RegDados->removido,"0");
    RegDados->nomeTecnologiaDestino=(char*)calloc(50,sizeof(char));
    RegDados->nomeTecnologiaOrigem=(char*)calloc(50,sizeof(char));
    return RegDados;
}

void LimpaRegistroDeDados(RegistroDeDados *RegDados){
    free(RegDados->nomeTecnologiaDestino);
    free(RegDados->nomeTecnologiaOrigem);
    free(RegDados);
}       

void PrintarDadosRegistro(RegistroDeDados *RegDados){
    char cifrao[2]="$";
    printf("%s",RegDados->nomeTecnologiaOrigem);
    if(RegDados->grupo==-1){
        printf(", NULO");
    }else{
        printf(", %d",RegDados->grupo);    
    }
    if(RegDados->popularidade==-1){
        printf(", NULO");
    }else{
    printf(", %d",RegDados->popularidade);    
    }
    if(RegDados->tamanhoTecnologiaDestino==0){
        printf(", NULO");
    }
    else{
        printf(", %s",RegDados->nomeTecnologiaDestino);    
    }
    if(RegDados->peso==-1){
        printf(", NULO\n");
    }else{
        printf(", %d\n",RegDados->peso);    
    }
}

RegistroDeDados *LeituraDados(RegistroDeDados *RegDados, FILE *arqConvertido){
    int tamanhoRegistro;

    fread(&(RegDados->removido),sizeof(char),1,arqConvertido);
    fread(&(RegDados->grupo),sizeof(int),1,arqConvertido);
    fread(&(RegDados->popularidade),sizeof(int),1,arqConvertido);
    fread(&(RegDados->peso),sizeof(int),1,arqConvertido);
    fread(&(RegDados->tamanhoTecnologiaOrigem),sizeof(int),1,arqConvertido);
    fread((RegDados->nomeTecnologiaOrigem),(RegDados->tamanhoTecnologiaOrigem)*sizeof(char),1,arqConvertido);
    fread(&(RegDados->tamanhoTecnologiaDestino),sizeof(int),1,arqConvertido);
    fread((RegDados->nomeTecnologiaDestino),(RegDados->tamanhoTecnologiaDestino)*sizeof(char),1,arqConvertido);

    tamanhoRegistro=76 - 21 -(RegDados->tamanhoTecnologiaOrigem+RegDados->tamanhoTecnologiaDestino);
    fseek(arqConvertido,tamanhoRegistro,SEEK_CUR);

    return RegDados;
}




int BuscaWhere(int escolha,int valor,char *nome,FILE *arqConvertido){
    RegistroDeDados *RegDados;
    RegistroCabecalho *RegCab;
    char readerChar;
    RegCab=CriaStructCabecalho();

    if (RegCab == NULL) {
        printf("Erro ao alocar memória\n"); //REMOVER NO FUTURO
        free(RegCab);
        return 1;
    }

    RegCab=LeituraCabecalho(RegCab,arqConvertido);
    
    if(RegCab->status=='0'){
        printf("Falha no processamento do arquivo.\n");
        free(RegCab);
        return 1;
    }
    while(fread(&readerChar,1,1,arqConvertido)!=0){
        ungetc(readerChar,arqConvertido);
        RegDados=CriaStructRegDados();
    
        if (RegDados ==NULL ) {
            printf("Erro ao alocar memória\n"); //REMOVER NO FUTURO
            LimpaRegistroDeDados(RegDados);
            free(RegCab);
            return 1;
        }
    
        RegDados=LeituraDados(RegDados,arqConvertido);
        
        if(escolha ==0 && RegDados->grupo==valor){
            PrintarDadosRegistro(RegDados);
        }
        else if(escolha ==1 && RegDados->popularidade==valor){
            PrintarDadosRegistro(RegDados);
        }
        else if(escolha ==2 && RegDados->peso==valor){
            PrintarDadosRegistro(RegDados);
        }
        else if(escolha ==3 && strcmp(RegDados->nomeTecnologiaOrigem,nome)==0){
            PrintarDadosRegistro(RegDados);
        }
        else if(escolha ==4 && strcmp(RegDados->nomeTecnologiaDestino,nome)==0){
            PrintarDadosRegistro(RegDados);
        }

        LimpaRegistroDeDados(RegDados);    
    }
    free(RegCab);
    return 0;
}

void EscrevePalavras(char *string,FILE *arq,int tamanho){
    fwrite(string,sizeof(char),tamanho,arq);
}