#ifndef __FUNCIONALIDADEFORNECIDA_H__
#define __FUNCIONALIDADEFORNECIDA_H__

#include "cabeca.h"
//FuncoesFornecidas
void scan_quote_string(char *str);
void binarioNaTela(char *nomeArquivoBinario);
void readline(char* string);
#endif