#include "FuncoesCabecalho.h"
#include "cabeca.h"
#include "AberturaArquivo.h"
#include "FuncoesDados.h"
#include "Funcionalidades.h"
#include "Funcoesfornecidas.h"
 
int main(){
    int escolha;
    int RRN;
    int n;
    char arqCSV[20];
    char arqBIN[20];
    scanf("%d",&escolha);
    //printf("escolha feita foi:%d\n",escolha); //REMOVER NO FUTURO
    switch(escolha){
        case 1:
        //printf("Caso1\n"); //REMOVER NO FUTURO
        scanf("%s",arqCSV);
        scanf("%s",arqBIN);
        createTable(arqCSV,arqBIN);
        break;
        case 2:
        //printf("Caso2\n"); //REMOVER NO FUTURO
        scanf("%s",arqBIN);
        SelectFrom(arqBIN);
        break;
        case 3:
        //printf("Caso3\n"); //REMOVER NO FUTURO
        scanf("%s",arqBIN);
        scanf("%d",&n);
        SelecWhere(arqBIN,n);
        break;
        case 4:
        //printf("Caso4\n"); //REMOVER NO FUTURO
        scanf("%s",arqBIN);
        scanf("%d",&RRN);
        RecuperaDados(arqBIN,RRN);
        break;
    }
}
