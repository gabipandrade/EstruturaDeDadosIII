#ifndef __ABRELEITURA_H__
#define __ABRELEITURA_H__

#include "cabeca.h"

//Funcoes de Abertura de Arquivo
FILE *AbreArquivoLeituraCSV(char *arq);
FILE *AbreArquivoLeituraBIN(char *arq);
FILE *AbreArquivoEscritaBIN(char *arq);

#endif