#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include "cabeca.h"
void leitura(char *arqOriginal,RegistroDeDados *RegDados){
    char *p;
    int MaxLinha=256;
    char *str1; // Variável para armazenar a primeira string
    int num1, num2, num3; // Variáveis para armazenar os números
    char *str2; // Variável para armazenar a segunda string
    str1=(char*)calloc(50,sizeof(char)); 
    str2=(char*)calloc(50,sizeof(char)); 
    p=(char*)calloc(256,sizeof(char)); 
    if (p == NULL || str1 ==NULL || str2==NULL) {
        printf("Erro ao alocar memória\n"); //REMOVER NO FUTURO
        free(p);
        free(str1);
        free(str2);
        return ;
    }
    fgets(p, MaxLinha, arqOriginal); //Ignora primeira linha
    while (fgets(p, MaxLinha, arqOriginal) != NULL) {    
        if (sscanf(p, "%49[^,],%d,%d,%49[^,],%d", str1, &num1, &num2, str2, &num3) == 5) {
            // Agora, as variáveis contêm os valores lidos
            //nomeTecnologiaOrigem,grupo,popularidade,nomeTecnologiaDestino,peso
            //str1=nomeTecnologiaOrigem
            //num1=grupo
            //num2=popularidade
            //str2=nomeTecnologiaDestino
            //num3=peso
            str1=realloc(str1,strlen(str1));
            str2=realloc(str2,strlen(str2));
            
            strcpy(RegDados->nomeTecnologiaOrigem,str1);
            RegDados->tamanhoTecnologiaOrigem=strlen(str1);
            RegDados->grupo=num1;
            RegDados->popularidade=num2;
            strcpy(RegDados->nomeTecnologiaDestino,str2);
            RegDados->tamanhoTecnologiaDestino=strlen(str2);
            RegDados->peso=num3;
            
        }
    }
    return;
}